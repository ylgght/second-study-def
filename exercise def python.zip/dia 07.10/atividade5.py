def inicio():
    x=int(input('Digite o Número:\n'))
    y=fator(x)
    return y
def fator(x):
    
    y=1
    z=1
    while z<=x:
        y*=z
        z+=1
    return y
y=inicio()
print(f'O valor fatorial deste Número é de : {y}')
