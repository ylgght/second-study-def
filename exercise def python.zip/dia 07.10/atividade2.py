def inicio():
    x=float(input('Digite o valor que você quer calcular o quadrado:\n'))
    y=quadrado(x)
    return y
def quadrado(x):
    a=x**2
    return a
y=inicio()
print(y)